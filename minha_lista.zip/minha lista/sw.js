const CACHE_NAME = 'minha-lista-cache-v2'; // Bumped junto com a v1.7.0 do app
const ASSETS = [
  './',
  './minhalisata.html',
  './manifest.json',
  './icon.jpg'
];

// Instalação do Service Worker e armazenamento dos arquivos estruturais em cache
self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      return cache.addAll(ASSETS);
    })
  );
  self.skipWaiting();
});

// Ativação e limpeza de caches antigos se houver atualização futura
self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) => {
      return Promise.all(
        keys.map((key) => {
          if (key !== CACHE_NAME) {
            return caches.delete(key);
          }
        })
      );
    })
  );
  self.clients.claim();
});

// Estratégia de Cache: Tenta carregar da rede, se falhar (offline), busca no cache
self.addEventListener('fetch', (event) => {
  event.respondWith(
    fetch(event.request).catch(() => {
      return caches.match(event.request);
    })
  );
});

